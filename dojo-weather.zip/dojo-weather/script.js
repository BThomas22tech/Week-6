console.log("im connected")
function hide(element){
    element = document.querySelector("#cookie-holder");
    element.remove();
}
