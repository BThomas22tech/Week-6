console.log("Im connected")

function hide(element) {
    element = document.getElementById('cookie-box');
    element.remove();
}

function over(element){
    element = document.getElementById('over').src="images/assets/succulents-2.jpg";
}

function out(element){
    element = document.getElementById('over').src="images/assets/succulents-1.jpg";
}