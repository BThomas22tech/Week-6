console.log("This is linked!");

var count1 = 9
var countElement1 = document.querySelector("#count1");
console.log(count1);

function add1(){
    count1++;
    countElement1.innerHTML= count1 + " like(s)";
    console.log(count1);
}
var count2 = 12
var countElement2 = document.querySelector("#count2");
console.log(count2);

function add2(){
    count2++;
    countElement2.innerHTML= count2 + " like(s)";
    console.log(count2);
}
var count3 = 9
var countElement3 = document.querySelector("#count3");
console.log(count3);

function add3(){
    count3++;
    countElement3.innerHTML= count3 + " like(s)";
    console.log(count3);
}